document.addEventListener("DOMContentLoaded", () => {
    
    const openMenuBtn = document.querySelector('.menu-btn');
    const closeMenuBtn = document.querySelector('.close-menu-btn');
    const sidebar = document.getElementById('mobile-sidebar');
    const overlay = document.getElementById('mobile-menu-overlay');

    if (openMenuBtn && sidebar && overlay) {
        const sidebarLinks = sidebar.querySelectorAll('a');

        function toggleSidebar(open) {
            if (open) {
                sidebar.classList.remove('translate-x-full');
                overlay.classList.remove('opacity-0', 'pointer-events-none');
            } else {
                sidebar.classList.add('translate-x-full');
                overlay.classList.add('opacity-0', 'pointer-events-none');
            }
        }

        openMenuBtn.addEventListener('click', () => toggleSidebar(true));
        if (closeMenuBtn) closeMenuBtn.addEventListener('click', () => toggleSidebar(false));
        overlay.addEventListener('click', () => toggleSidebar(false));

        sidebarLinks.forEach(link => {
            link.addEventListener('click', () => toggleSidebar(false));
        });
    }

    const navbar = document.getElementById('main-navbar');
    let lastScrollY = window.scrollY;

    window.addEventListener('scroll', () => {
        if (!navbar) return;
        
        if (window.scrollY > lastScrollY && window.scrollY > 80) {
            navbar.classList.add('-translate-y-full');
        } else {
            navbar.classList.remove('-translate-y-full');
        }
        lastScrollY = window.scrollY;
    });

    fetch('./loader.html')
        .then(response => {
            if (!response.ok) throw new Error("Loader non trovato");
            return response.text();
        })
        .then(html => {
            document.body.insertAdjacentHTML('afterbegin', html);
            const loader = document.getElementById('global-loader');
            
            window.addEventListener('load', () => {
                hideLoader(loader);
            });

            if (document.readyState === 'complete') {
                hideLoader(loader);
            }

            setupLinkTransitions(loader);
        })
        .catch(err => console.warn("Nota sul loader:", err.message));
    
    checkRegistrationDeadline();
});

function hideLoader(loader) {
    if (!loader) return;
    loader.classList.add('opacity-0', 'pointer-events-none');
    setTimeout(() => {
        loader.classList.add('hidden');
    }, 500);
}

function setupLinkTransitions(loader) {
    if (!loader) return;
    const links = document.querySelectorAll('a');
    links.forEach(link => {
        const href = link.getAttribute('href');
        
        if (
            href && 
            !href.startsWith('#') && 
            !href.startsWith('mailto:') && 
            !href.startsWith('tel:') && 
            link.getAttribute('target') !== '_blank' &&
            !link.hasAttribute('download')
        ) {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                
                loader.classList.remove('hidden');
                setTimeout(() => {
                    loader.classList.remove('opacity-0', 'pointer-events-none');
                }, 10);

                setTimeout(() => {
                    window.location.href = href;
                }, 300); 
            });
        }
    });
}

function checkRegistrationDeadline() {
    const deadline = new Date('2026-02-01T00:00:00').getTime();
    
    const dDays = document.getElementById('countdown-days');
    const dHours = document.getElementById('countdown-hours');
    const dMins = document.getElementById('countdown-minutes');
    const dSecs = document.getElementById('countdown-seconds');
    const countdownContainer = document.getElementById('countdown-container');

    function handleExpiration() {
        if (countdownContainer) {
            countdownContainer.classList.add('hidden');
        }

        const btnIscrizione = document.getElementById('iscrizione-btn');
        const btnDistintaPDF = document.getElementById('distinta-btn');
        const infoIscrizione = document.getElementById('iscrizione-info-text');

        if (btnIscrizione && btnIscrizione.parentNode) {
            const newBtn = btnIscrizione.cloneNode(true);
            btnIscrizione.parentNode.replaceChild(newBtn, btnIscrizione);
            
            newBtn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
            });
            newBtn.removeAttribute('href');
            newBtn.className = "hidden";
            newBtn.innerHTML = "<i class='fa-solid fa-lock mr-2'></i> Iscrizioni Chiuse";
        }

        if (infoIscrizione) {
            infoIscrizione.innerHTML = "<b>Il termine ultimo per le iscrizioni (30/06/2026) è superato.</b>";
            infoIscrizione.className = "text-sm text-red-500 mt-2.5 text-center block w-full";
        }

        if (btnDistintaPDF) {
            btnDistintaPDF.classList.add('hidden');
        }
    }

    const now = new Date().getTime();
    if (deadline - now <= 0) {
        handleExpiration();
        return;
    }

    function updateTimer() {
        const today = new Date().getTime();
        const timeLeft = deadline - today;

        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            handleExpiration();
            return;
        }

        const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
        const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);

        if (dDays) dDays.innerText = days < 10 ? '0' + days : days;
        if (dHours) dHours.innerText = hours < 10 ? '0' + hours : hours;
        if (dMins) dMins.innerText = minutes < 10 ? '0' + minutes : minutes;
        if (dSecs) dSecs.innerText = seconds < 10 ? '0' + seconds : seconds;
    }

    updateTimer();
    const timerInterval = setInterval(updateTimer, 1000);
}